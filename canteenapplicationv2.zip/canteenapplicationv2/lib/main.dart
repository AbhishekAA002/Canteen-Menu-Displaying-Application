import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_firebase_series/screens/fetch_data.dart';
import 'package:flutter_firebase_series/screens/insert_data.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Canteen App'),
        backgroundColor: Color(0xFF303F9F),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const Text(
              'Canteen Admin Application',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 70,
            ),
            ClipOval(
              child: Image.network(
                'https://dt19wmazj2dns.cloudfront.net/wp-content/uploads/2014/03/amrita1_0.jpg',
                width: 300,
                height: 300,
                fit: BoxFit.cover,
              ),
            ),

            // const Image(
            //   width: 300,
            //   height: 300,
            //   image: NetworkImage(
            //       'https://dt19wmazj2dns.cloudfront.net/wp-content/uploads/2014/03/amrita1_0.jpg'),
            // ),

            // const Text(
            //   'Canteen Admin Application',
            //   style: TextStyle(
            //     fontSize: 24,
            //     fontWeight: FontWeight.w500,
            //   ),
            //   textAlign: TextAlign.center,
            // ),
            // const SizedBox(
            //   height: 30,
            // ),
            // MaterialButton(
            //   onPressed: () {
            //     Navigator.push(
            //         context,
            //         MaterialPageRoute(
            //             builder: (context) => const InsertData()));
            //   },
            //   child: const Text('Add New Items'),
            //   color: Colors.blue,
            //   textColor: Colors.white,
            //   minWidth: 300,
            //   height: 40,
            // ),
            // const SizedBox(
            //   height: 30,
            // ),
            // MaterialButton(
            //   onPressed: () {
            //     Navigator.push(context,
            //         MaterialPageRoute(builder: (context) => const FetchData()));
            //   },
            //   child: const Text('Modify Items'),
            //   color: Colors.blue,
            //   textColor: Colors.white,
            //   minWidth: 300,
            //   height: 40,
            // ),


            const SizedBox(height: 50),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const InsertData()));
              },
              child: const Text('Add New Items'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                primary: Color(0xFF303F9F),
                onPrimary: Colors.white,
                elevation: 5,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const FetchData()));
              },
              child: const Text('Modify Items'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(300, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                primary: Color(0xFF303F9F),
                onPrimary: Colors.white,
                elevation: 5,
              ),
            ),





          ],
        ),
      ),
    );
  }
}

// import 'package:firebase_core/firebase_core.dart';
// import 'package:flut/ter/material.dart';
// import 'screens/fetch_data.dart';
// import 'screens/insert_data.dart';
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp();
//   runApp(const MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Canteen App',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//         fontFamily: 'Roboto', // Example: Use Roboto font
//         visualDensity: VisualDensity.adaptivePlatformDensity,
//       ),
//       home: const MyHomePage(),
//     );
//   }
// }
//
// class MyHomePage extends StatelessWidget {
//   const MyHomePage({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Canteen Admin App'),
//         centerTitle: true,
//       ),
//       body: Center(
//         child: Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: <Widget>[
//               ClipOval(
//                 child: Image.network(
//                   'https://dt19wmazj2dns.cloudfront.net/wp-content/uploads/2014/03/amrita1_0.jpg',
//                   width: 150,
//                   height: 150,
//                   fit: BoxFit.cover,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               const Text(
//                 'Canteen Admin Application',
//                 style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//                 textAlign: TextAlign.center,
//               ),
//               const SizedBox(height: 30),
//               ElevatedButton(
//                 onPressed: () {
//                   Navigator.push(context, MaterialPageRoute(builder: (context) => const InsertData()));
//                 },
//                 child: const Text('Add New Items'),
//                 style: ElevatedButton.styleFrom(
//                   minimumSize: const Size(300, 50),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                   ),
//                   primary: Colors.blue,
//                   onPrimary: Colors.white,
//                   elevation: 5,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: () {
//                   Navigator.push(context, MaterialPageRoute(builder: (context) => const FetchData()));
//                 },
//                 child: const Text('Modify Items'),
//                 style: ElevatedButton.styleFrom(
//                   minimumSize: const Size(300, 50),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                   ),
//                   primary: Colors.blue,
//                   onPrimary: Colors.white,
//                   elevation: 5,
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }








// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter/material.dart';
// import 'screens/fetch_data.dart';
// import 'screens/insert_data.dart';
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp();
//   runApp(const MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Canteen App',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//         visualDensity: VisualDensity.adaptivePlatformDensity,
//       ),
//       home: const MyHomePage(),
//     );
//   }
// }
//
// class MyHomePage extends StatelessWidget {
//   const MyHomePage({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Canteen Admin App'),
//         centerTitle: true,
//       ),
//       body: Center(
//         child: Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: <Widget>[
//               ClipOval(
//                 child: Image.network(
//                   'https://dt19wmazj2dns.cloudfront.net/wp-content/uploads/2014/03/amrita1_0.jpg',
//                   width: 150,
//                   height: 150,
//                   fit: BoxFit.cover,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               const Text(
//                 'Canteen Admin Application',
//                 style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//                 textAlign: TextAlign.center,
//               ),
//               const SizedBox(height: 30),
//               ElevatedButton(
//                 onPressed: () {
//                   Navigator.push(context, MaterialPageRoute(builder: (context) => const InsertData()));
//                 },
//                 child: const Text('Add New Items'),
//                 style: ElevatedButton.styleFrom(minimumSize: const Size(300, 40)),
//               ),
//               const SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: () {
//                   Navigator.push(context, MaterialPageRoute(builder: (context) => const FetchData()));
//                 },
//                 child: const Text('Modify Items'),
//                 style: ElevatedButton.styleFrom(minimumSize: const Size(300, 40)),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }


