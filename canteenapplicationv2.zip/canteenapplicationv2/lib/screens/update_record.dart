import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class UpdateRecord extends StatefulWidget {
  final String studentKey;

  const UpdateRecord({Key? key, required this.studentKey}) : super(key: key);

  @override
  State<UpdateRecord> createState() => _UpdateRecordState();
}

class _UpdateRecordState extends State<UpdateRecord> {
  final TextEditingController itemNameController = TextEditingController();
  final TextEditingController itemPriceController = TextEditingController();
  final TextEditingController itemQuantityController = TextEditingController();

  late DatabaseReference dbRef;

  @override
  void initState() {
    super.initState();
    dbRef = FirebaseDatabase.instance.ref().child('MenuItems');
    getItemData();
  }

  Future<void> getItemData() async {
    DataSnapshot snapshot = await dbRef.child(widget.studentKey).get();
    final Map<String, String> item = Map<String, String>.from(snapshot.value as Map);

    itemNameController.text = item['item'] ?? '';
    itemPriceController.text = item['price'] ?? '';
    itemQuantityController.text = item['quantity'] ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Update Item'),
        backgroundColor: const Color(0xFF303F9F),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Update Item Details',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            TextField(
              controller: itemNameController,
              keyboardType: TextInputType.text,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Item Name',
                hintText: 'Change Item Name',
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: itemPriceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Price',
                hintText: 'Change Price of Item',
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: itemQuantityController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Quantity',
                hintText: 'Change Item Quantity',
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                final Map<String, String> updatedItem = {
                  'item': itemNameController.text,
                  'price': itemPriceController.text,
                  'quantity': itemQuantityController.text,
                };

                dbRef.child(widget.studentKey).update(updatedItem).then((_) {
                  Navigator.pop(context);
                });
              },
              child: const Text('Update Item'),
              style: ElevatedButton.styleFrom(
                primary: const Color(0xFF303F9F),
                minimumSize: const Size(double.infinity, 40),
              ),
            ),
          ],
        ),
      ),
    );
  }
}




//
//
//
// import 'package:firebase_database/firebase_database.dart';
// import 'package:flutter/material.dart';
//
// class UpdateRecord extends StatefulWidget {
//
//   const UpdateRecord({Key? key, required this.studentKey}) : super(key: key);
//
//   final String studentKey;
//
//   @override
//   State<UpdateRecord> createState() => _UpdateRecordState();
// }
//
// class _UpdateRecordState extends State<UpdateRecord> {
//
//   final  userNameController = TextEditingController();
//   final  userAgeController= TextEditingController();
//   final  userSalaryController =TextEditingController();
//
//   late DatabaseReference dbRef;
//
//   @override
//   void initState() {
//     super.initState();
//     dbRef = FirebaseDatabase.instance.ref().child('Students');
//     getStudentData();
//   }
//
//   void getStudentData() async {
//     DataSnapshot snapshot = await dbRef.child(widget.studentKey).get();
//
//     Map student = snapshot.value as Map;
//
//     userNameController.text = student['item'];
//     userAgeController.text = student['price'];
//     userSalaryController.text = student['quantity'];
//
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Updating record'),
//       ),
//       body:  Center(
//         child: Padding(
//           padding: EdgeInsets.all(8.0),
//           child: Column(
//             children: [
//               const SizedBox(
//                 height: 50,
//               ),
//               const Text(
//                 'Updating data in Firebase Realtime Database',
//                 style: TextStyle(
//                   fontSize: 24,
//                   fontWeight: FontWeight.w500,
//                 ),
//                 textAlign: TextAlign.center,
//               ),
//               const SizedBox(
//                 height: 30,
//               ),
//               TextField(
//                 controller: userNameController,
//                 keyboardType: TextInputType.text,
//                 decoration: const InputDecoration(
//                   border: OutlineInputBorder(),
//                   labelText: 'Item Name',
//                   hintText: 'Change Item Name',
//                 ),
//               ),
//               const SizedBox(
//                 height: 30,
//               ),
//               TextField(
//                 controller: userAgeController,
//                 keyboardType: TextInputType.number,
//                 decoration: const InputDecoration(
//                   border: OutlineInputBorder(),
//                   labelText: 'Price',
//                   hintText: 'Change Price of Item',
//                 ),
//               ),
//               const SizedBox(
//                 height: 30,
//               ),
//               TextField(
//                 controller: userSalaryController,
//                 keyboardType: TextInputType.phone,
//                 decoration: const InputDecoration(
//                   border: OutlineInputBorder(),
//                   labelText: 'Quantity',
//                   hintText: 'Change Item Quantity',
//                 ),
//               ),
//               const SizedBox(
//                 height: 30,
//               ),
//               MaterialButton(
//                 onPressed: () {
//
//                   Map<String, String> students = {
//                     'item': userNameController.text,
//                     'price': userAgeController.text,
//                     'quantity': userSalaryController.text
//                   };
//
//                   dbRef.child(widget.studentKey).update(students)
//                       .then((value) => {
//                     Navigator.pop(context)
//                   });
//
//                 },
//                 child: const Text('Update Data'),
//                 color: Colors.blue,
//                 textColor: Colors.white,
//                 minWidth: 300,
//                 height: 40,
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }