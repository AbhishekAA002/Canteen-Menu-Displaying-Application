import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class InsertData extends StatefulWidget {
  const InsertData({Key? key}) : super(key: key);

  @override
  State<InsertData> createState() => _InsertDataState();
}

class _InsertDataState extends State<InsertData> {
  final TextEditingController itemNameController = TextEditingController();
  final TextEditingController itemPriceController = TextEditingController();
  final TextEditingController itemQuantityController = TextEditingController();

  late DatabaseReference dbRef;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    dbRef = FirebaseDatabase.instance.ref().child('MenuItems');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add New Items'),
        centerTitle: true,
        elevation: 2,
        backgroundColor: Color(0xFF303F9F),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // const Text(
            //   'Adding New Items to the Menu',
            //   style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            //   textAlign: TextAlign.center,
            // ),
            const SizedBox(height: 30),
            _buildTextField(itemNameController, 'Item Name', 'Enter Item Name'),
            const SizedBox(height: 20),
            _buildTextField(itemPriceController, 'Price', 'Enter Price of Item', TextInputType.number),
            const SizedBox(height: 20),
            _buildTextField(itemQuantityController, 'Quantity', 'Enter Item Quantity', TextInputType.number),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: isLoading ? null : _addItem,
              child: isLoading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text('Add Item'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                backgroundColor: Color(0xFF303F9F),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller,
      String label,
      String hint, [
        TextInputType keyboardType = TextInputType.text,
      ]) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
      ),
    );
  }

  Future<void> _addItem() async {
    if (itemNameController.text.isEmpty ||
        itemPriceController.text.isEmpty ||
        itemQuantityController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill in all fields.'),
        ),
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      final Map<String, String> menuItem = {
        'item': itemNameController.text,
        'price': itemPriceController.text,
        'quantity': itemQuantityController.text,
      };

      await dbRef.push().set(menuItem);
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to add item: $e'),
        ),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }
}








// import 'package:firebase_database/firebase_database.dart';
// import 'package:flutter/material.dart';
//
// class InsertData extends StatefulWidget {
//   const InsertData({Key? key}) : super(key: key);
//
//   @override
//   State<InsertData> createState() => _InsertDataState();
// }
//
// class _InsertDataState extends State<InsertData> {
//   final TextEditingController itemNameController = TextEditingController();
//   final TextEditingController itemPriceController = TextEditingController();
//   final TextEditingController itemQuantityController = TextEditingController();
//
//   late DatabaseReference dbRef;
//
//   @override
//   void initState() {
//     super.initState();
//     dbRef = FirebaseDatabase.instance.ref().child('MenuItems');
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Add New Items'),
//         centerTitle: true,
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             const Text(
//               'Adding New Items to the Menu',
//               style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
//               textAlign: TextAlign.center,
//             ),
//             const SizedBox(height: 30),
//             TextField(
//               controller: itemNameController,
//               keyboardType: TextInputType.text,
//               decoration: const InputDecoration(
//                 border: OutlineInputBorder(),
//                 labelText: 'Item Name',
//                 hintText: 'Enter Item Name',
//               ),
//             ),
//             const SizedBox(height: 20),
//             TextField(
//               controller: itemPriceController,
//               keyboardType: TextInputType.number,
//               decoration: const InputDecoration(
//                 border: OutlineInputBorder(),
//                 labelText: 'Price',
//                 hintText: 'Enter Price of Item',
//               ),
//             ),
//             const SizedBox(height: 20),
//             TextField(
//               controller: itemQuantityController,
//               keyboardType: TextInputType.number,
//               decoration: const InputDecoration(
//                 border: OutlineInputBorder(),
//                 labelText: 'Quantity',
//                 hintText: 'Enter Item Quantity',
//               ),
//             ),
//             const SizedBox(height: 30),
//             ElevatedButton(
//               onPressed: () {
//                 final Map<String, String> menuItem = {
//                   'item': itemNameController.text,
//                   'price': itemPriceController.text,
//                   'quantity': itemQuantityController.text,
//                 };
//                 dbRef.push().set(menuItem).then((_) {
//                   ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
//                     content: Text('Item successfully added!'),
//                   ));
//                   Navigator.pop(context);
//                 });
//               },
//               child: const Text('Add Item'),
//               style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 40)),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
//
//
//
// // import 'package:firebase_database/firebase_database.dart';
// // import 'package:flutter/material.dart';
// //
// // class InsertData extends StatefulWidget {
// //   const InsertData({Key? key}) : super(key: key);
// //
// //   @override
// //   State<InsertData> createState() => _InsertDataState();
// // }
// //
// // class _InsertDataState extends State<InsertData> {
// //
// //   final  userNameController = TextEditingController();
// //   final  userAgeController= TextEditingController();
// //   final  userSalaryController =TextEditingController();
// //
// //   late DatabaseReference dbRef;
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     dbRef = FirebaseDatabase.instance.ref().child('Students');
// //   }
// //
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: Text('Canteen App'),
// //       ),
// //       body: Center(
// //         child: Padding(
// //           padding: EdgeInsets.all(8.0),
// //           child: Column(
// //             children: [
// //               const SizedBox(
// //                 height: 50,
// //               ),
// //               const Text(
// //                 'Adding New Items to the Menu',
// //                 style: TextStyle(
// //                   fontSize: 24,
// //                   fontWeight: FontWeight.w500,
// //                 ),
// //                 textAlign: TextAlign.center,
// //               ),
// //               const SizedBox(
// //                 height: 30,
// //               ),
// //               TextField(
// //                 controller: userNameController,
// //                 keyboardType: TextInputType.text,
// //                 decoration: const InputDecoration(
// //                   border: OutlineInputBorder(),
// //                   labelText: 'Item Name',
// //                   hintText: 'Enter Item Name',
// //                 ),
// //               ),
// //               const SizedBox(
// //                 height: 30,
// //               ),
// //               TextField(
// //                 controller: userAgeController,
// //                 keyboardType: TextInputType.number,
// //                 decoration: const InputDecoration(
// //                   border: OutlineInputBorder(),
// //                   labelText: 'Price',
// //                   hintText: 'Enter Price of Item',
// //                 ),
// //               ),
// //               const SizedBox(
// //                 height: 30,
// //               ),
// //               TextField(
// //                 controller: userSalaryController,
// //                 keyboardType: TextInputType.phone,
// //                 decoration: const InputDecoration(
// //                   border: OutlineInputBorder(),
// //                   labelText: 'Quantity',
// //                   hintText: 'Enter Item Quantity',
// //                 ),
// //               ),
// //               const SizedBox(
// //                 height: 30,
// //               ),
// //               MaterialButton(
// //                 onPressed: () {
// //                   Map<String, String> students = {
// //                     'item': userNameController.text,
// //                     'price': userAgeController.text,
// //                     'quantity': userSalaryController.text
// //                   };
// //
// //                   dbRef.push().set(students);
// //
// //                 },
// //                 child: const Text('Add Item'),
// //                 color: Colors.blue,
// //                 textColor: Colors.white,
// //                 minWidth: 300,
// //                 height: 40,
// //               ),
// //             ],
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// // }