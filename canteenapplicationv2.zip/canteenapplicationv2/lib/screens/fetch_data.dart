import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_firebase_series/screens/update_record.dart';

class FetchData extends StatefulWidget {
  const FetchData({Key? key}) : super(key: key);

  @override
  State<FetchData> createState() => _FetchDataState();
}

class _FetchDataState extends State<FetchData> {
  late DatabaseReference dbRef, dbRef1; //
  List<Map<String, dynamic>> items = []; // Changed type to Map<String, dynamic>

  @override
  void initState() {
    super.initState();
    //
    dbRef1 = FirebaseDatabase.instance.ref().child('ViewItems');
    //
    dbRef = FirebaseDatabase.instance.ref().child('MenuItems');
    dbRef.onValue.listen((event) {
      final data = Map<String, dynamic>.from(event.snapshot.value as Map);
      items = data.entries.map((e) {
        final value = Map<String, dynamic>.from(e.value as Map); // Changed type to Map<String, dynamic>
        return {'key': e.key, 'checked': false, ...value}; // Added 'checked' field
      }).toList();
      setState(() {});
    });
  }

  Widget listItem({required Map<String, dynamic> item}) { // Changed type to Map<String, dynamic>
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              item['item'] ?? 'N/A',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'Price: ${item['price']}',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 8),
            Text(
              'Quantity: ${item['quantity']}',
              style: TextStyle(fontSize: 16),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // Checkbox(
                //   value: item['checked'],
                //   onChanged: (bool? value) async {
                //     setState(() {
                //       item['checked'] = value;
                //     });
                //     if(value!) {
                //       try {
                //         final Map<String, String> viewItem = {
                //           'item': item['item'],
                //           'price': item['price'],
                //           'quantity': item['quantity'],
                //         };
                //
                //         await dbRef1.push().set(viewItem);
                //         // Navigator.pop(context);
                //       } catch (e) {
                //         ScaffoldMessenger.of(context).showSnackBar(
                //           SnackBar(
                //             content: Text('Failed to add item: $e'),
                //           ),
                //         );
                //       }
                //     } else {
                //       // final String? key = item['key'];
                //       dbRef1.child(item['key']!).remove();
                //     }
                //   },
                // ),
                Checkbox(
                  value: item['checked'],
                  onChanged: (bool? value) async {
                    setState(() {
                      item['checked'] = value;
                    });
                    if (value!) {
                      try {
                        final Map<String, String> viewItem = {
                          'item': item['item'],
                          'price': item['price'],
                          'quantity': item['quantity'],
                        };

                        DatabaseReference newItemRef = dbRef1.push();
                        await newItemRef.set(viewItem);
                        setState(() {
                          item['viewItemKey'] = newItemRef.key; // Save the key of the new item
                        });
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Failed to add item: $e'),
                          ),
                        );
                      }
                    } else {
                      if (item['viewItemKey'] != null) {
                        dbRef1.child(item['viewItemKey']).remove();
                        setState(() {
                          item['viewItemKey'] = null; // Clear the key since the item is removed
                        });
                      }
                    }
                  },
                ),

                IconButton(
                  icon: Icon(
                    Icons.edit,
                    color: Theme.of(context).primaryColor,
                  ),
                  onPressed: () {
                    final String? key = item['key'];
                    if (key != null) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => UpdateRecord(studentKey: key),
                        ),
                      );
                    } else {
                      // Handle the case where key is null, if necessary
                      print('Error: Trying to edit an item without a key');
                    }
                  },
                ),
                IconButton(
                  icon: Icon(
                    Icons.delete,
                    color: Colors.red,
                  ),
                  onPressed: () {
                    dbRef.child(item['key']!).remove();
                  },
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Modify Items'),
        centerTitle: true,
        backgroundColor: const Color(0xFF303F9F), // Sample color code
      ),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          return listItem(item: items[index]);
        },
      ),
    );
  }
}







// import 'package:firebase_database/firebase_database.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_firebase_series/screens/update_record.dart';
//
// class FetchData extends StatefulWidget {
//   const FetchData({Key? key}) : super(key: key);
//
//   @override
//   State<FetchData> createState() => _FetchDataState();
// }
//
// class _FetchDataState extends State<FetchData> {
//   late DatabaseReference dbRef;
//   List<Map<String, String>> items = [];
//
//   @override
//   void initState() {
//     super.initState();
//     dbRef = FirebaseDatabase.instance.ref().child('MenuItems');
//     dbRef.onValue.listen((event) {
//       final data = Map<String, dynamic>.from(event.snapshot.value as Map);
//       items = data.entries.map((e) {
//         final value = Map<String, String>.from(e.value as Map);
//         return {'key': e.key, ...value};
//       }).toList();
//       setState(() {});
//     });
//   }
//
//   Widget listItem({required Map<String, String> item}) {
//     return Card(
//       elevation: 2,
//       margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
//       child: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               item['item'] ?? 'N/A',
//               style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//             ),
//             const SizedBox(height: 8),
//             Text(
//               'Price: ${item['price']}',
//               style: TextStyle(fontSize: 16),
//             ),
//             const SizedBox(height: 8),
//             Text(
//               'Quantity: ${item['quantity']}',
//               style: TextStyle(fontSize: 16),
//             ),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.end,
//               children: [
//                 IconButton(
//                   icon: Icon(
//                     Icons.edit,
//                     color: Theme.of(context).primaryColor,
//                   ),
//                   onPressed: () {
//                     final String? key = item['key'];
//                     if (key != null) {
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(
//                           builder: (_) => UpdateRecord(studentKey: key),
//                         ),
//                       );
//                     } else {
//                       // Handle the case where key is null, if necessary
//                       print('Error: Trying to edit an item without a key');
//                     }
//                   },
//                 ),
//
//                 IconButton(
//                   icon: Icon(
//                     Icons.delete,
//                     color: Colors.red,
//                   ),
//                   onPressed: () {
//                     dbRef.child(item['key']!).remove();
//                   },
//
//
//
//
//
//                 ),
//               ],
//             )
//           ],
//         ),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Modify Items'),
//         centerTitle: true,
//         backgroundColor: const Color(0xFF303F9F), // Sample color code
//       ),
//       body: ListView.builder(
//         itemCount: items.length,
//         itemBuilder: (context, index) {
//           return listItem(item: items[index]);
//         },
//       ),
//     );
//   }
// }
//
//
//
//
//
//
//
// //
// // import 'package:firebase_database/firebase_database.dart';
// // import 'package:flutter/material.dart';
// //
// // class FetchData extends StatefulWidget {
// //   const FetchData({Key? key}) : super(key: key);
// //
// //   @override
// //   State<FetchData> createState() => _FetchDataState();
// // }
// //
// // class _FetchDataState extends State<FetchData> {
// //   late DatabaseReference dbRef;
// //   List<Map<String, String>> items = [];
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     dbRef = FirebaseDatabase.instance.ref().child('MenuItems');
// //     dbRef.onValue.listen((event) {
// //       final data = Map<String, dynamic>.from(event.snapshot.value as Map);
// //       items = data.entries.map((e) {
// //         final value = Map<String, String>.from(e.value as Map);
// //         return {'key': e.key, ...value};
// //       }).toList();
// //       setState(() {});
// //     });
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text('Modify Items'),
// //         centerTitle: true,
// //       ),
// //       body: ListView.builder(
// //         itemCount: items.length,
// //         itemBuilder: (context, index) {
// //           final item = items[index];
// //           return ListTile(
// //             title: Text(item['item'] ?? 'N/A'),
// //             subtitle: Text('Price: ${item['price']} | Quantity: ${item['quantity']}'),
// //             trailing: Row(
// //               mainAxisSize: MainAxisSize.min,
// //               children: [
// //                 IconButton(
// //                   icon: const Icon(Icons.edit),
// //                   onPressed: () {
// //                     // Add your edit functionality here
// //                   },
// //                 ),
// //                 IconButton(
// //                   icon: const Icon(Icons.delete),
// //                   onPressed: () {
// //                     dbRef.child(item['key']!).remove();
// //                   },
// //                 ),
// //               ],
// //             ),
// //           );
// //         },
// //       ),
// //     );
// //   }
// // }
//
//
//
//
// //
// // import 'package:firebase_database/firebase_database.dart';
// // import 'package:firebase_database/ui/firebase_animated_list.dart';
// // import 'package:flutter/material.dart';
// // import 'package:flutter_firebase_series/screens/update_record.dart';
// //
// // class FetchData extends StatefulWidget {
// //   const FetchData({Key? key}) : super(key: key);
// //
// //   @override
// //   State<FetchData> createState() => _FetchDataState();
// // }
// //
// // class _FetchDataState extends State<FetchData> {
// //   Query dbRef = FirebaseDatabase.instance.ref().child('Students');
// //   DatabaseReference reference = FirebaseDatabase.instance.ref().child('Students');
// //
// //   Widget listItem({required Map student}) {
// //     return Card(
// //       elevation: 2,
// //       margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
// //       child: InkWell(
// //         onTap: () {
// //           Navigator.push(
// //               context,
// //               MaterialPageRoute(
// //                   builder: (_) => UpdateRecord(studentKey: student['key'])));
// //         },
// //         child: Padding(
// //           padding: const EdgeInsets.all(16.0),
// //           child: Column(
// //             mainAxisSize: MainAxisSize.min,
// //             crossAxisAlignment: CrossAxisAlignment.start,
// //             children: [
// //               Text(
// //                 student['item'],
// //                 style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
// //               ),
// //               const SizedBox(
// //                 height: 8,
// //               ),
// //               Text(
// //                 'Price: ${student['price']}',
// //                 style: TextStyle(fontSize: 16),
// //               ),
// //               const SizedBox(
// //                 height: 8,
// //               ),
// //               Text(
// //                 'Quantity: ${student['quantity']}',
// //                 style: TextStyle(fontSize: 16),
// //               ),
// //               Row(
// //                 mainAxisAlignment: MainAxisAlignment.end,
// //                 children: [
// //                   IconButton(
// //                     icon: Icon(
// //                       Icons.edit,
// //                       color: Theme.of(context).primaryColor,
// //                     ),
// //                     onPressed: () {
// //                       Navigator.push(
// //                           context,
// //                           MaterialPageRoute(
// //                               builder: (_) => UpdateRecord(studentKey: student['key'])));
// //                     },
// //                   ),
// //                   IconButton(
// //                     icon: Icon(
// //                       Icons.delete,
// //                       color: Colors.red,
// //                     ),
// //                     onPressed: () {
// //                       reference.child(student['key']).remove();
// //                     },
// //                   ),
// //                 ],
// //               )
// //             ],
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text('Fetching data'),
// //         backgroundColor: Color(0xFF303F9F), // Sample color code
// //       ),
// //       body: FirebaseAnimatedList(
// //         query: dbRef,
// //         itemBuilder: (BuildContext context, DataSnapshot snapshot, Animation<double> animation, int index) {
// //           Map student = snapshot.value as Map;
// //           student['key'] = snapshot.key;
// //           return listItem(student: student);
// //         },
// //       ),
// //     );
// //   }
// // }
//
//
//
//
//
//
//
//
//
//
//
//
//
// // import 'package:firebase_database/firebase_database.dart';
// // import 'package:firebase_database/ui/firebase_animated_list.dart';
// // import 'package:flutter/material.dart';
// // import 'package:flutter_firebase_series/screens/update_record.dart';
// //
// // class FetchData extends StatefulWidget {
// //   const FetchData({Key? key}) : super(key: key);
// //
// //   @override
// //   State<FetchData> createState() => _FetchDataState();
// // }
// //
// // class _FetchDataState extends State<FetchData> {
// //
// //   Query dbRef = FirebaseDatabase.instance.ref().child('Students');
// //   DatabaseReference reference = FirebaseDatabase.instance.ref().child('Students');
// //
// //   Widget listItem({required Map student}) {
// //     return Container(
// //       margin: const EdgeInsets.all(10),
// //       padding: const EdgeInsets.all(10),
// //       height: 110,
// //       color: Colors.amberAccent,
// //       child: Column(
// //         mainAxisAlignment: MainAxisAlignment.center,
// //         crossAxisAlignment: CrossAxisAlignment.start,
// //         children: [
// //           Text(
// //             student['name'],
// //             style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
// //           ),
// //           const SizedBox(
// //             height: 5,
// //           ),
// //           Text(
// //             student['age'],
// //             style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
// //           ),
// //           const SizedBox(
// //             height: 5,
// //           ),
// //           Text(
// //             student['salary'],
// //             style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
// //           ),
// //           Row(
// //             mainAxisAlignment: MainAxisAlignment.end,
// //             crossAxisAlignment: CrossAxisAlignment.center,
// //             children: [
// //               GestureDetector(
// //                 onTap: () {
// //                   Navigator.push(context, MaterialPageRoute(builder: (_) => UpdateRecord(studentKey: student['key'])));
// //                 },
// //                 child: Row(
// //                   children: [
// //                     Icon(
// //                       Icons.edit,
// //                       color: Theme.of(context).primaryColor,
// //                     ),
// //                   ],
// //                 ),
// //               ),
// //               const SizedBox(
// //                 width: 6,
// //               ),
// //               GestureDetector(
// //                 onTap: () {
// //                   reference.child(student['key']).remove();
// //                 },
// //                 child: Row(
// //                   children: [
// //                     Icon(
// //                       Icons.delete,
// //                       color: Colors.red[700],
// //                     ),
// //                   ],
// //                 ),
// //               ),
// //             ],
// //           )
// //         ],
// //       ),
// //     );
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //         appBar: AppBar(
// //           title: const Text('Fetching data'),
// //         ),
// //         body: SizedBox(
// //           height: double.infinity,
// //           child: FirebaseAnimatedList(
// //             query: dbRef,
// //             itemBuilder: (BuildContext context, DataSnapshot snapshot, Animation<double> animation, int index) {
// //
// //               Map student = snapshot.value as Map;
// //               student['key'] = snapshot.key;
// //
// //               return listItem(student: student);
// //
// //             },
// //           ),
// //         )
// //     );
// //   }
// // }